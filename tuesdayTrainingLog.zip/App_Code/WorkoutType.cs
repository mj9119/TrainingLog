﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for WorkoutType
/// </summary>
public class WorkoutType
{
	public WorkoutType()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public string UserEmail { get; set; }
    public string TypeOfWorkout { get; set; }
}